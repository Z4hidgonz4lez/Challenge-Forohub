package com.principal.apiforo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiforoApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApiforoApplication.class, args);
	}
}

