package com.principal.apiforo.entities;

public enum Status {
    ACTIVO,
    INACTIVO
}
