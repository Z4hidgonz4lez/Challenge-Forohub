package com.principal.apiforo.config;

public @interface Server {

}
